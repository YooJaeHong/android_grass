package com.example.git_grass_reader;


import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.core.app.NotificationCompat;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private String id = "깃헙 아이디";
    private String htmlPageUrl = "https://github.com/" + id;

    private TextView textviewHtmlDocument;

    private String htmlContentInStringFormat;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//grass
        textviewHtmlDocument = (TextView) findViewById(R.id.textView);
        textviewHtmlDocument.setMovementMethod(new ScrollingMovementMethod());

        Button htmlTitleButton = (Button) findViewById(R.id.btn_grass);

        htmlTitleButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                JsoupAsyncTask jsoupAsyncTask = new JsoupAsyncTask();
                jsoupAsyncTask.execute();
            }

        });
//grass end

        //notification start
        findViewById(R.id.btn_noti).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                //Bitmap mLargeIconForNoti = BitmapFactory.decodeResource(getResources(), R.drawable.image1);

                PendingIntent mPendingIntent = PendingIntent.getActivity(MainActivity.this, 0,
                        new Intent(getApplicationContext(), MainActivity.class),
                        PendingIntent.FLAG_UPDATE_CURRENT
                );


                NotificationCompat.Builder mBuilder =
                        new NotificationCompat.Builder(MainActivity.this)
                                //.setSmallIcon(R.drawable.image0)
                                .setContentTitle("알림 제목")
                                .setContentText("내용")
                                .setDefaults(Notification.DEFAULT_VIBRATE)
                                //.setLargeIcon(mLargeIconForNoti)
                                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                                .setAutoCancel(true)
                                .setContentIntent(mPendingIntent);

                NotificationManager mNotificationManager =
                        (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                mNotificationManager.notify(0, mBuilder.build());
            }
        });
        //notification end
    }

    private class JsoupAsyncTask extends AsyncTask<Void, Void, Void> {
        protected void onPreExecute() {
            super.onPreExecute();
        }

        protected Void doInBackground(Void... params) {
            try {
                Document doc = Jsoup.connect(htmlPageUrl).get();
                Elements dates = doc.select("rect[class=day]");
                List<String> all_date = new ArrayList<>();
                List<String> all_colors = new ArrayList<>();

                for(Element date: dates){
                    all_date.add(date.attr("abs:data-date"));
                    all_colors.add(date.attr("abs:fill"));
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;

        }//읽어오기

        protected void onPostExecute(Void result) {
            textviewHtmlDocument.setText(htmlContentInStringFormat);
        }
    }
}
