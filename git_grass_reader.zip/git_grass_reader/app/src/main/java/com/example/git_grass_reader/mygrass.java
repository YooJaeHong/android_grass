package com.example.git_grass_reader;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TabHost;

public class mygrass extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mygrass);


        TabHost tabhost1 = (TabHost) findViewById(R.id.taphost_mygrass);
        tabhost1.setup();
        TabHost.TabSpec ts1 = tabhost1.newTabSpec("Tab Spec 1");
        ts1.setContent(R.id.tab1);
        ts1.setIndicator("내잔디밭");
        tabhost1.addTab(ts1);

        TabHost.TabSpec ts2 = tabhost1.newTabSpec("Tab Spec 2");
        ts2.setContent(R.id.tab2);
        ts2.setIndicator("팀잔디밭");
        tabhost1.addTab(ts2);

        TabHost.TabSpec ts3 = tabhost1.newTabSpec("Tab Spec 3");
        ts3.setContent(R.id.tab3);
        ts3.setIndicator("새로운잔디밭");
        tabhost1.addTab(ts3);
    }
}
